-- Roblox 3D Admin Map - Client GUI
-- Place this LocalScript in StarterPlayer > StarterPlayerScripts.
-- Touch-friendly layout for phones/tablets and mouse-friendly for PC.
-- Server checks all admin actions. Replace the UserId in the server script.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")

local player = Players.LocalPlayer
local remote = ReplicatedStorage:WaitForChild("AdminMapRemote")

local gui = Instance.new("ScreenGui")
gui.Name = "AdminMapPanel"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = false
gui.Parent = player:WaitForChild("PlayerGui")

local function addCorner(object, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius or 12)
    corner.Parent = object
end

local function makeButton(parent, text, color)
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(1, 0, 0, 42)
    button.BackgroundColor3 = color or Color3.fromRGB(49, 105, 190)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Text = text
    button.TextScaled = true
    button.Font = Enum.Font.GothamBold
    button.AutoButtonColor = true
    button.Parent = parent
    addCorner(button, 9)
    return button
end

local openButton = Instance.new("TextButton")
openButton.Name = "OpenAdminButton"
openButton.Size = UDim2.new(0, 126, 0, 44)
openButton.Position = UDim2.new(0, 14, 0.5, -22)
openButton.BackgroundColor3 = Color3.fromRGB(35, 95, 180)
openButton.TextColor3 = Color3.new(1, 1, 1)
openButton.Text = "⚙ ADMIN"
openButton.TextScaled = true
openButton.Font = Enum.Font.GothamBold
openButton.Visible = false
openButton.Parent = gui
addCorner(openButton, 12)

local panel = Instance.new("Frame")
panel.Name = "Panel"
panel.Size = UDim2.new(0, 310, 0, 430)
panel.Position = UDim2.new(0, 14, 0.5, -215)
panel.BackgroundColor3 = Color3.fromRGB(20, 25, 38)
panel.Visible = false
panel.Parent = gui
addCorner(panel, 14)

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -54, 0, 44)
title.Position = UDim2.new(0, 14, 0, 4)
title.BackgroundTransparency = 1
title.Text = "3D MAP • ADMIN"
title.TextColor3 = Color3.fromRGB(115, 210, 255)
title.TextScaled = true
title.Font = Enum.Font.GothamBlack
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = panel

local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 38, 0, 38)
closeButton.Position = UDim2.new(1, -44, 0, 7)
closeButton.BackgroundColor3 = Color3.fromRGB(170, 55, 65)
closeButton.Text = "X"
closeButton.TextColor3 = Color3.new(1, 1, 1)
closeButton.TextScaled = true
closeButton.Font = Enum.Font.GothamBold
closeButton.Parent = panel
addCorner(closeButton, 9)

local targetLabel = Instance.new("TextLabel")
targetLabel.Size = UDim2.new(1, -28, 0, 24)
targetLabel.Position = UDim2.new(0, 14, 0, 52)
targetLabel.BackgroundTransparency = 1
targetLabel.Text = "Target player:"
targetLabel.TextColor3 = Color3.fromRGB(230, 235, 245)
targetLabel.TextSize = 14
targetLabel.Font = Enum.Font.Gotham
targetLabel.TextXAlignment = Enum.TextXAlignment.Left
targetLabel.Parent = panel

local targetBox = Instance.new("TextBox")
targetBox.Size = UDim2.new(1, -28, 0, 38)
targetBox.Position = UDim2.new(0, 14, 0, 78)
targetBox.BackgroundColor3 = Color3.fromRGB(39, 47, 65)
targetBox.TextColor3 = Color3.new(1, 1, 1)
targetBox.PlaceholderText = "Exact username (you can use your own)"
targetBox.PlaceholderColor3 = Color3.fromRGB(170, 180, 195)
targetBox.Text = player.Name
targetBox.TextSize = 14
targetBox.Font = Enum.Font.Gotham
targetBox.ClearTextOnFocus = false
targetBox.Parent = panel
addCorner(targetBox, 9)

local scroll = Instance.new("ScrollingFrame")
scroll.Size = UDim2.new(1, -28, 1, -170)
scroll.Position = UDim2.new(0, 14, 0, 126)
scroll.BackgroundTransparency = 1
scroll.BorderSizePixel = 0
scroll.ScrollBarThickness = 5
scroll.CanvasSize = UDim2.new(0, 0, 0, 330)
scroll.Parent = panel

local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 8)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = scroll

local status = Instance.new("TextLabel")
status.Size = UDim2.new(1, -28, 0, 30)
status.Position = UDim2.new(0, 14, 1, -38)
status.BackgroundTransparency = 1
status.Text = "Admin tools locked until verified"
status.TextColor3 = Color3.fromRGB(255, 210, 100)
status.TextSize = 12
status.Font = Enum.Font.Gotham
status.TextWrapped = true
status.Parent = panel

local isAdmin = false
local function findTargetId()
    local query = string.lower(targetBox.Text:gsub("^%s+", ""):gsub("%s+$", ""))
    if query == "" then return nil end
    for _, other in ipairs(Players:GetPlayers()) do
        if string.lower(other.Name) == query or string.lower(other.DisplayName) == query then
            return other.UserId
        end
    end
    return nil
end

local function requestAction(action, value)
    if not isAdmin then
        status.Text = "Not authorized. Add your UserId in the server script."
        return
    end
    local targetId = findTargetId()
    if action == "Announce" then
        remote:FireServer("Announce", targetBox.Text)
    elseif targetId then
        remote:FireServer(action, targetId, value)
    else
        status.Text = "Player not found. Enter an online username exactly."
    end
end

local heal = makeButton(scroll, "♥  Heal player", Color3.fromRGB(35, 145, 105))
heal.LayoutOrder = 1
heal.Activated:Connect(function() requestAction("Heal") end)

local speed = makeButton(scroll, "⚡  Speed boost (32)", Color3.fromRGB(49, 105, 190))
speed.LayoutOrder = 2
speed.Activated:Connect(function() requestAction("Speed", 32) end)

local jump = makeButton(scroll, "↑  High jump", Color3.fromRGB(130, 80, 190))
jump.LayoutOrder = 3
jump.Activated:Connect(function() requestAction("Jump", 75) end)

local teleport = makeButton(scroll, "⌂  Teleport to spawn", Color3.fromRGB(190, 120, 45))
teleport.LayoutOrder = 4
teleport.Activated:Connect(function() requestAction("TeleportToSpawn") end)

local announceBox = Instance.new("TextBox")
announceBox.Size = UDim2.new(1, 0, 0, 38)
announceBox.BackgroundColor3 = Color3.fromRGB(39, 47, 65)
announceBox.TextColor3 = Color3.new(1, 1, 1)
announceBox.PlaceholderText = "Announcement text"
announceBox.Text = ""
announceBox.TextSize = 14
announceBox.Font = Enum.Font.Gotham
announceBox.ClearTextOnFocus = false
announceBox.LayoutOrder = 5
announceBox.Parent = scroll
addCorner(announceBox, 9)

local announce = makeButton(scroll, "📢  Send announcement", Color3.fromRGB(175, 75, 75))
announce.LayoutOrder = 6
announce.Activated:Connect(function()
    if not isAdmin then
        status.Text = "Not authorized. Add your UserId in the server script."
        return
    end
    if announceBox.Text ~= "" then
        remote:FireServer("Announce", announceBox.Text)
        status.Text = "Announcement sent."
    end
end)

openButton.Activated:Connect(function()
    panel.Visible = not panel.Visible
end)
closeButton.Activated:Connect(function()
    panel.Visible = false
end)

remote.OnClientEvent:Connect(function(kind, value)
    if kind == "AdminStatus" then
        isAdmin = value == true
        openButton.Visible = isAdmin
        if isAdmin then
            status.Text = "Verified admin • controls enabled"
            status.TextColor3 = Color3.fromRGB(100, 235, 160)
        else
            panel.Visible = false
        end
    elseif kind == "Announcement" then
        pcall(function()
            StarterGui:SetCore("SendNotification", {
                Title = "SERVER ANNOUNCEMENT",
                Text = tostring(value),
                Duration = 6
            })
        end)
    end
end)

remote:FireServer("RequestStatus")
