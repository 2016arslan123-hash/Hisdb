-- Roblox 3D Admin Map - Server Script
-- Place this Script in ServerScriptService.
-- IMPORTANT: Replace 123456789 with your Roblox UserId before publishing.
-- Admin permissions are checked on the server; don't rely on the client GUI for security.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Lighting = game:GetService("Lighting")

local ADMIN_USER_IDS = {
    [123456789] = true, -- Replace with your Roblox UserId
}

local remote = ReplicatedStorage:FindFirstChild("AdminMapRemote")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "AdminMapRemote"
    remote.Parent = ReplicatedStorage
end

local function makePart(parent, name, size, position, color, material)
    local part = Instance.new("Part")
    part.Name = name
    part.Size = size
    part.Position = position
    part.Anchored = true
    part.Color = color
    part.Material = material or Enum.Material.SmoothPlastic
    part.TopSurface = Enum.SurfaceType.Smooth
    part.BottomSurface = Enum.SurfaceType.Smooth
    part.Parent = parent
    return part
end

local function createMap()
    if workspace:FindFirstChild("AdminShowcaseMap") then return end

    local map = Instance.new("Folder")
    map.Name = "AdminShowcaseMap"
    map.Parent = workspace

    Lighting.ClockTime = 14
    Lighting.Brightness = 2
    Lighting.Ambient = Color3.fromRGB(145, 155, 175)
    Lighting.OutdoorAmbient = Color3.fromRGB(170, 180, 195)

    makePart(map, "MainIsland", Vector3.new(180, 4, 180), Vector3.new(0, -2, 0),
        Color3.fromRGB(77, 166, 93), Enum.Material.Grass)
    makePart(map, "SpawnPlatform", Vector3.new(24, 1, 24), Vector3.new(0, 1, 0),
        Color3.fromRGB(50, 170, 255), Enum.Material.Neon)

    -- Simple paths and platforms
    makePart(map, "PathWest", Vector3.new(55, 1, 8), Vector3.new(-35, 0, 0),
        Color3.fromRGB(190, 190, 200), Enum.Material.Concrete)
    makePart(map, "PathEast", Vector3.new(55, 1, 8), Vector3.new(35, 0, 0),
        Color3.fromRGB(190, 190, 200), Enum.Material.Concrete)
    makePart(map, "ObbyPlatform1", Vector3.new(12, 2, 12), Vector3.new(0, 5, -28),
        Color3.fromRGB(255, 190, 60), Enum.Material.SmoothPlastic)
    makePart(map, "ObbyPlatform2", Vector3.new(12, 2, 12), Vector3.new(0, 9, -45),
        Color3.fromRGB(255, 110, 90), Enum.Material.SmoothPlastic)
    makePart(map, "ObbyPlatform3", Vector3.new(16, 2, 16), Vector3.new(0, 13, -62),
        Color3.fromRGB(185, 100, 255), Enum.Material.SmoothPlastic)

    -- Decorative towers
    for i = 1, 4 do
        local x = (i % 2 == 0) and 65 or -65
        local z = (i <= 2) and 55 or -55
        makePart(map, "TowerBase" .. i, Vector3.new(12, 2, 12), Vector3.new(x, 0, z),
            Color3.fromRGB(65, 80, 110), Enum.Material.Slate)
        makePart(map, "Tower" .. i, Vector3.new(8, 22, 8), Vector3.new(x, 12, z),
            Color3.fromRGB(65, 135, 220), Enum.Material.Metal)
        makePart(map, "TowerTop" .. i, Vector3.new(14, 2, 14), Vector3.new(x, 24, z),
            Color3.fromRGB(80, 220, 255), Enum.Material.Neon)
    end

    local spawn = Instance.new("SpawnLocation")
    spawn.Name = "AdminMapSpawn"
    spawn.Size = Vector3.new(8, 1, 8)
    spawn.Position = Vector3.new(0, 2, 0)
    spawn.Anchored = true
    spawn.Neutral = true
    spawn.Color = Color3.fromRGB(255, 255, 255)
    spawn.Material = Enum.Material.Neon
    spawn.Parent = map
end

createMap()

local function isAdmin(player)
    return ADMIN_USER_IDS[player.UserId] == true
end

local function getTarget(targetUserId)
    if typeof(targetUserId) ~= "number" then return nil end
    for _, player in ipairs(Players:GetPlayers()) do
        if player.UserId == targetUserId then
            return player
        end
    end
    return nil
end

local function announce(message)
    local safeMessage = tostring(message):sub(1, 120)
    remote:FireAllClients("Announcement", safeMessage)
end

remote.OnServerEvent:Connect(function(player, action, targetUserId, value)
    if not isAdmin(player) then
        warn(("Blocked non-admin request from %s (%d)"):format(player.Name, player.UserId))
        return
    end

    if action == "RequestStatus" then
        remote:FireClient(player, "AdminStatus", true)
        return
    end

    if action == "Announce" then
        if typeof(targetUserId) == "string" and #targetUserId > 0 then
            announce(targetUserId)
        end
        return
    end

    local target = getTarget(targetUserId)
    if not target then return end

    local character = target.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if action == "Heal" and humanoid then
        humanoid.Health = humanoid.MaxHealth
    elseif action == "Speed" and humanoid then
        local speed = math.clamp(tonumber(value) or 16, 8, 50)
        humanoid.WalkSpeed = speed
    elseif action == "Jump" and humanoid then
        local power = math.clamp(tonumber(value) or 50, 25, 100)
        humanoid.UseJumpPower = true
        humanoid.JumpPower = power
    elseif action == "TeleportToSpawn" and character then
        character:PivotTo(CFrame.new(0, 5, 0))
    end
end)

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        task.wait(0.25)
        if character and character.Parent then
            remote:FireClient(player, "AdminStatus", isAdmin(player))
        end
    end)
end)
