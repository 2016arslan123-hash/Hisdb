# Roblox 3D Admin Map

A starter Roblox Studio project with a simple 3D showcase map and a touch-friendly admin panel for phone/tablet and PC.

## Files
- `ServerScriptService/AdminMapServer.lua` — creates the map and securely validates admin commands.
- `StarterPlayer/StarterPlayerScripts/AdminPanelClient.lua` — creates the admin GUI.

## Install in Roblox Studio
1. Create a new Baseplate experience.
2. In **ServerScriptService**, create a **Script** named `AdminMapServer` and paste in `AdminMapServer.lua`.
3. In **StarterPlayer > StarterPlayerScripts**, create a **LocalScript** named `AdminPanelClient` and paste in `AdminPanelClient.lua`.
4. Open the server script and replace `123456789` with your Roblox numeric UserId. You can find it in your Roblox profile URL.
5. Press **Play** to test. The map is generated automatically. Only the listed UserId can see the Admin button and use admin actions.
6. Publish your experience when you're ready.

## Included
- Green island map, spawn platform, paths, towers, and simple obby platforms.
- Admin panel with heal, speed, high jump, teleport to spawn, and server announcement.
- Server-side permission check so non-admin clients cannot run these actions just by firing the RemoteEvent.

## Important
- Replace the placeholder UserId before publishing.
- This is a starter template, not a full HD Admin replacement.
- Test changes in a private test experience before using them in a public game.
